function mudou1 (){
    document.form1.completo.value=document.form1.value
}

function mudou2(){
    document.form1.completo.value=document.form1.nome.value + " " + document.form1.sobrenome.value;
}